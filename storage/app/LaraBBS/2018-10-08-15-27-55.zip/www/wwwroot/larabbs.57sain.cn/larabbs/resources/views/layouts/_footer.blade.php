<footer class="footer">
    <div class="container">
        <p class="pull-left">
            由 <a href="http://weibo.com/u/1837553744?is_hot=1" target="_blank">Summer</a> 设计和编码 <span style="color: #e27575;font-size: 14px;">❤</span>
        </p>

        <p class="pull-right"><a href="mailto:{{ setting('contact_email') }}">联系我们</a></p>
    </div>
</footer>